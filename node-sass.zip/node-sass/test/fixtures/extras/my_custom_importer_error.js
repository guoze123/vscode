module.exports = function() {
  return new Error('doesn\'t exist!');
};
